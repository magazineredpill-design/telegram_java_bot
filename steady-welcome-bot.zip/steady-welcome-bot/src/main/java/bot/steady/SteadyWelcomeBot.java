package bot.steady;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.telegram.telegrambots.bots.DefaultBotOptions;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.ChatMemberUpdated;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

/**
 * Bot che, quando un utente entra in un gruppo/canale, mostra un link Steady.
 * Link, testo, pulsante, modalita' e admin sono configurabili via comandi
 * (solo in chat privata con il bot, solo per gli amministratori).
 */
public class SteadyWelcomeBot extends TelegramLongPollingBot {

    private static final Logger LOG = Logger.getLogger(SteadyWelcomeBot.class.getName());

    /** Evita il doppio benvenuto quando arrivano sia il messaggio di servizio sia l'update chat_member. */
    private static final long DEDUP_MS = 15_000;
    private static final int MAX_MESSAGE_LEN = 3000;
    private static final int MAX_BUTTON_LEN = 64;

    private final BotConfig config;
    private final Map<String, Long> recentWelcomes = new ConcurrentHashMap<>();

    public SteadyWelcomeBot(DefaultBotOptions options, BotConfig config) {
        super(options, config.getToken());
        this.config = config;
    }

    @Override
    public String getBotUsername() {
        return config.getUsername();
    }

    // =====================================================================
    //  Ricezione update
    // =====================================================================

    @Override
    public void onUpdateReceived(Update update) {
        try {
            if (update.hasChatMember()) {
                handleChatMember(update.getChatMember());
            }
            if (update.hasMessage()) {
                handleMessage(update.getMessage());
            }
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Errore nella gestione di un update", e);
        }
    }

    private void handleChatMember(ChatMemberUpdated change) {
        String oldStatus = change.getOldChatMember().getStatus();
        String newStatus = change.getNewChatMember().getStatus();
        boolean wasOutside = "left".equals(oldStatus) || "kicked".equals(oldStatus);
        if (wasOutside && "member".equals(newStatus)) {
            welcome(change.getChat().getId(), change.getNewChatMember().getUser());
        }
    }

    private void handleMessage(Message message) {
        List<User> joined = message.getNewChatMembers();
        if (joined != null) {
            for (User user : joined) {
                welcome(message.getChatId(), user);
            }
        }
        if (message.hasText() && message.isCommand()) {
            handleCommand(message);
        }
    }

    // =====================================================================
    //  Benvenuto
    // =====================================================================

    private void welcome(long chatId, User user) {
        if (Boolean.TRUE.equals(user.getIsBot()) || !config.isWelcomeEnabled()) {
            return;
        }
        String link = config.getSteadyLink();
        if (link.isBlank()) {
            LOG.warning("Nuovo utente ma nessun link Steady configurato: usa /setlink.");
            return;
        }

        long now = System.currentTimeMillis();
        recentWelcomes.values().removeIf(t -> now - t > DEDUP_MS);
        String key = chatId + ":" + user.getId();
        Long previous = recentWelcomes.put(key, now);
        if (previous != null && now - previous < DEDUP_MS) {
            return;
        }

        long target = "private".equals(config.getWelcomeMode()) ? user.getId() : chatId;
        sendWelcome(target, user, link);
    }

    private void sendWelcome(long targetChatId, User user, String link) {
        InlineKeyboardButton button = InlineKeyboardButton.builder()
                .text(config.getButtonText())
                .url(link)
                .build();
        SendMessage msg = SendMessage.builder()
                .chatId(String.valueOf(targetChatId))
                .text(render(config.getMessage(), user, link))
                .parseMode("HTML")
                .replyMarkup(InlineKeyboardMarkup.builder().keyboardRow(List.of(button)).build())
                .build();
        try {
            execute(msg);
        } catch (TelegramApiException e) {
            // In modalita' "private" fallisce se l'utente non ha mai avviato il bot.
            LOG.log(Level.WARNING, "Invio benvenuto non riuscito (chat " + targetChatId + "): " + e.getMessage());
        }
    }

    private static String render(String template, User user, String link) {
        String name = user.getFirstName() != null ? user.getFirstName() : "amico";
        String mention = "<a href=\"tg://user?id=" + user.getId() + "\">" + escapeHtml(name) + "</a>";
        return escapeHtml(template)
                .replace("{name}", mention)
                .replace("{link}", escapeHtml(link));
    }

    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // =====================================================================
    //  Comandi (solo chat privata)
    // =====================================================================

    private void handleCommand(Message m) {
        if (!m.getChat().isUserChat() || m.getFrom() == null) {
            return; // i comandi funzionano solo in privato
        }
        long chatId = m.getChatId();
        long userId = m.getFrom().getId();

        String text = m.getText().trim();
        int sp = firstWhitespace(text);
        String cmd = sp < 0 ? text : text.substring(0, sp);
        String args = sp < 0 ? "" : text.substring(sp).trim();
        int at = cmd.indexOf('@');
        if (at > 0) {
            cmd = cmd.substring(0, at);
        }
        cmd = cmd.toLowerCase(Locale.ROOT);

        if (cmd.equals("/myid")) {
            reply(chatId, "Il tuo ID Telegram e': " + userId);
            return;
        }
        if (cmd.equals("/start") || cmd.equals("/help")) {
            reply(chatId, config.isAdmin(userId) ? helpText() : "Ciao! Questo bot da' il benvenuto ai nuovi iscritti.\n"
                    + "Usa /myid per conoscere il tuo ID Telegram.");
            return;
        }
        if (!config.isAdmin(userId)) {
            reply(chatId, "Non sei autorizzato a usare questo comando.");
            return;
        }

        switch (cmd) {
            case "/getconfig":
                reply(chatId, configSummary());
                break;
            case "/setlink":
                setLink(chatId, args);
                break;
            case "/setmessage":
                setMessage(chatId, args);
                break;
            case "/setbutton":
                setButton(chatId, args);
                break;
            case "/welcome":
                setWelcome(chatId, args);
                break;
            case "/setmode":
                setMode(chatId, args);
                break;
            case "/addadmin":
                addAdmin(chatId, args);
                break;
            case "/removeadmin":
                removeAdmin(chatId, userId, args);
                break;
            case "/test":
                test(chatId, m.getFrom());
                break;
            default:
                reply(chatId, "Comando sconosciuto. Usa /help.");
        }
    }

    private void setLink(long chatId, String args) {
        if (!isValidHttpsUrl(args)) {
            reply(chatId, "Uso: /setlink https://steadyhq.com/...\nIl link deve iniziare con https://");
            return;
        }
        config.setSteadyLink(args);
        reply(chatId, "Link Steady aggiornato:\n" + args);
    }

    private void setMessage(long chatId, String args) {
        if (args.isBlank() || args.length() > MAX_MESSAGE_LEN) {
            reply(chatId, "Uso: /setmessage <testo>\nSegnaposto: {name} = nome utente, {link} = link Steady.\n"
                    + "Massimo " + MAX_MESSAGE_LEN + " caratteri; puoi andare a capo.");
            return;
        }
        config.setMessage(args);
        reply(chatId, "Messaggio di benvenuto aggiornato. Usa /test per vedere l'anteprima.");
    }

    private void setButton(long chatId, String args) {
        if (args.isBlank() || args.length() > MAX_BUTTON_LEN) {
            reply(chatId, "Uso: /setbutton <testo del pulsante> (max " + MAX_BUTTON_LEN + " caratteri)");
            return;
        }
        config.setButtonText(args);
        reply(chatId, "Testo del pulsante aggiornato: " + args);
    }

    private void setWelcome(long chatId, String args) {
        if (args.equalsIgnoreCase("on")) {
            config.setWelcomeEnabled(true);
            reply(chatId, "Benvenuto ATTIVATO.");
        } else if (args.equalsIgnoreCase("off")) {
            config.setWelcomeEnabled(false);
            reply(chatId, "Benvenuto DISATTIVATO.");
        } else {
            reply(chatId, "Uso: /welcome on  oppure  /welcome off");
        }
    }

    private void setMode(long chatId, String args) {
        if (args.equalsIgnoreCase("chat") || args.equalsIgnoreCase("private")) {
            config.setWelcomeMode(args);
            reply(chatId, "Modalita' impostata: " + config.getWelcomeMode()
                    + ("private".equals(config.getWelcomeMode())
                            ? "\n(il messaggio arriva in privato solo a chi ha gia' avviato il bot)" : ""));
        } else {
            reply(chatId, "Uso: /setmode chat  oppure  /setmode private");
        }
    }

    private void addAdmin(long chatId, String args) {
        Long id = parseLong(args);
        if (id == null) {
            reply(chatId, "Uso: /addadmin <ID numerico Telegram>\n(l'utente puo' scoprirlo con /myid)");
            return;
        }
        reply(chatId, config.addAdmin(id) ? "Amministratore aggiunto: " + id : "Quell'utente e' gia' amministratore.");
    }

    private void removeAdmin(long chatId, long requesterId, String args) {
        Long id = parseLong(args);
        if (id == null) {
            reply(chatId, "Uso: /removeadmin <ID numerico Telegram>");
            return;
        }
        if (id == requesterId) {
            reply(chatId, "Non puoi rimuovere te stesso.");
            return;
        }
        reply(chatId, config.removeAdmin(id) ? "Amministratore rimosso: " + id
                : "Non trovato tra gli admin aggiunti da comando (quelli in config.properties si tolgono da li').");
    }

    private void test(long chatId, User admin) {
        String link = config.getSteadyLink();
        if (link.isBlank()) {
            reply(chatId, "Nessun link configurato. Usa /setlink.");
            return;
        }
        sendWelcome(chatId, admin, link);
    }

    private String configSummary() {
        String link = config.getSteadyLink();
        return "Configurazione attuale\n"
                + "Benvenuto: " + (config.isWelcomeEnabled() ? "attivo" : "disattivato") + "\n"
                + "Modalita': " + config.getWelcomeMode() + "\n"
                + "Link Steady: " + (link.isBlank() ? "(non impostato)" : link) + "\n"
                + "Pulsante: " + config.getButtonText() + "\n"
                + "Admin: " + config.getAllAdmins() + "\n"
                + "Messaggio:\n" + config.getMessage();
    }

    private static String helpText() {
        return "Comandi amministratore (solo in questa chat privata):\n\n"
                + "/getconfig - mostra la configurazione\n"
                + "/setlink <url> - imposta il link Steady\n"
                + "/setmessage <testo> - imposta il messaggio ({name}, {link})\n"
                + "/setbutton <testo> - testo del pulsante\n"
                + "/welcome on|off - attiva/disattiva il benvenuto\n"
                + "/setmode chat|private - dove inviare il benvenuto\n"
                + "/addadmin <id> - aggiungi un amministratore\n"
                + "/removeadmin <id> - rimuovi un amministratore\n"
                + "/test - anteprima del benvenuto\n"
                + "/myid - mostra il tuo ID Telegram";
    }

    // =====================================================================
    //  Utilita'
    // =====================================================================

    private void reply(long chatId, String text) {
        try {
            execute(SendMessage.builder().chatId(String.valueOf(chatId)).text(text).build());
        } catch (TelegramApiException e) {
            LOG.log(Level.WARNING, "Invio risposta non riuscito: " + e.getMessage());
        }
    }

    private static int firstWhitespace(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (Character.isWhitespace(s.charAt(i))) {
                return i;
            }
        }
        return -1;
    }

    private static Long parseLong(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static boolean isValidHttpsUrl(String s) {
        if (s == null || s.isBlank() || s.length() > 2000) {
            return false;
        }
        try {
            URI uri = new URI(s.trim());
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
        } catch (URISyntaxException e) {
            return false;
        }
    }
}
