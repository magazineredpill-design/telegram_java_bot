package bot.steady;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Configurazione del bot.
 *  - config.properties: valori iniziali (token, admin iniziali, default).
 *  - settings.properties: valori modificati dall'amministratore a runtime
 *    (hanno la precedenza e sopravvivono al riavvio).
 */
public final class BotConfig {

    public static final String DEFAULT_MESSAGE =
            "Benvenuto/a {name}! \uD83D\uDC4B\nEcco il link al nostro post su Steady:\n{link}";
    public static final String DEFAULT_BUTTON = "Apri su Steady";

    private static final String K_LINK = "steady.link";
    private static final String K_MESSAGE = "welcome.message";
    private static final String K_BUTTON = "welcome.button";
    private static final String K_ENABLED = "welcome.enabled";
    private static final String K_MODE = "welcome.mode";
    private static final String K_ADMINS = "admin.ids";
    private static final String K_EXTRA_ADMINS = "admin.ids.extra";

    private final Properties base;
    private final Properties runtime;
    private final Path settingsPath;

    private BotConfig(Properties base, Properties runtime, Path settingsPath) {
        this.base = base;
        this.runtime = runtime;
        this.settingsPath = settingsPath;
    }

    public static BotConfig load(Path configFile) throws IOException {
        if (!Files.exists(configFile)) {
            throw new FileNotFoundException("File di configurazione non trovato: " + configFile.toAbsolutePath());
        }
        Properties base = new Properties();
        try (Reader r = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) {
            base.load(r);
        }
        Path parent = configFile.toAbsolutePath().getParent();
        Path settings = parent.resolve(base.getProperty("settings.file", "data/settings.properties").trim());

        Properties runtime = new Properties();
        if (Files.exists(settings)) {
            try (Reader r = Files.newBufferedReader(settings, StandardCharsets.UTF_8)) {
                runtime.load(r);
            }
        }
        return new BotConfig(base, runtime, settings);
    }

    // ---------- lettura ----------

    public synchronized String getToken() {
        String env = System.getenv("TELEGRAM_BOT_TOKEN");
        return (env != null && !env.isBlank()) ? env.trim() : base.getProperty("bot.token", "").trim();
    }

    public synchronized String getUsername() {
        String env = System.getenv("TELEGRAM_BOT_USERNAME");
        String name = (env != null && !env.isBlank()) ? env.trim() : base.getProperty("bot.username", "").trim();
        return name.startsWith("@") ? name.substring(1) : name;
    }

    private String get(String key, String def) {
        return runtime.getProperty(key, base.getProperty(key, def));
    }

    public synchronized String getSteadyLink() {
        return get(K_LINK, "").trim();
    }

    public synchronized String getMessage() {
        String m = get(K_MESSAGE, DEFAULT_MESSAGE);
        return m.isBlank() ? DEFAULT_MESSAGE : m;
    }

    public synchronized String getButtonText() {
        String b = get(K_BUTTON, DEFAULT_BUTTON).trim();
        return b.isEmpty() ? DEFAULT_BUTTON : b;
    }

    public synchronized boolean isWelcomeEnabled() {
        return Boolean.parseBoolean(get(K_ENABLED, "true").trim());
    }

    /** "chat" oppure "private". */
    public synchronized String getWelcomeMode() {
        return "private".equalsIgnoreCase(get(K_MODE, "chat").trim()) ? "private" : "chat";
    }

    // ---------- scrittura (salvata su disco) ----------

    public synchronized void setSteadyLink(String link) {
        runtime.setProperty(K_LINK, link);
        save();
    }

    public synchronized void setMessage(String message) {
        runtime.setProperty(K_MESSAGE, message);
        save();
    }

    public synchronized void setButtonText(String text) {
        runtime.setProperty(K_BUTTON, text);
        save();
    }

    public synchronized void setWelcomeEnabled(boolean enabled) {
        runtime.setProperty(K_ENABLED, Boolean.toString(enabled));
        save();
    }

    public synchronized void setWelcomeMode(String mode) {
        runtime.setProperty(K_MODE, "private".equalsIgnoreCase(mode) ? "private" : "chat");
        save();
    }

    // ---------- amministratori ----------

    private static Set<Long> parseIds(String s) {
        Set<Long> ids = new LinkedHashSet<>();
        if (s == null) {
            return ids;
        }
        for (String part : s.split("[,;\\s]+")) {
            if (part.isBlank()) {
                continue;
            }
            try {
                ids.add(Long.parseLong(part.trim()));
            } catch (NumberFormatException ignored) {
                // valore non valido: ignorato
            }
        }
        return ids;
    }

    /** Admin definiti in config.properties (non rimovibili da comando). */
    public synchronized Set<Long> getBaseAdmins() {
        return parseIds(base.getProperty(K_ADMINS, ""));
    }

    /** Admin aggiunti da comando (/addadmin). */
    public synchronized Set<Long> getExtraAdmins() {
        return parseIds(runtime.getProperty(K_EXTRA_ADMINS, ""));
    }

    public synchronized Set<Long> getAllAdmins() {
        Set<Long> all = new LinkedHashSet<>(getBaseAdmins());
        all.addAll(getExtraAdmins());
        return all;
    }

    public synchronized boolean isAdmin(long userId) {
        return getAllAdmins().contains(userId);
    }

    public synchronized boolean addAdmin(long userId) {
        if (isAdmin(userId)) {
            return false;
        }
        Set<Long> extra = getExtraAdmins();
        extra.add(userId);
        storeExtraAdmins(extra);
        return true;
    }

    /** Rimuove solo gli admin aggiunti da comando. */
    public synchronized boolean removeAdmin(long userId) {
        Set<Long> extra = getExtraAdmins();
        if (!extra.remove(userId)) {
            return false;
        }
        storeExtraAdmins(extra);
        return true;
    }

    private void storeExtraAdmins(Set<Long> extra) {
        runtime.setProperty(K_EXTRA_ADMINS,
                extra.stream().map(String::valueOf).collect(Collectors.joining(",")));
        save();
    }

    // ---------- persistenza ----------

    private void save() {
        try {
            Path dir = settingsPath.toAbsolutePath().getParent();
            if (dir != null) {
                Files.createDirectories(dir);
            }
            try (Writer w = Files.newBufferedWriter(settingsPath, StandardCharsets.UTF_8)) {
                runtime.store(w, "Impostazioni modificate dall'amministratore tramite il bot");
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Impossibile salvare " + settingsPath, e);
        }
    }
}
