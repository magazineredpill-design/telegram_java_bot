package bot.steady;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.telegram.telegrambots.bots.DefaultBotOptions;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

/**
 * Punto di ingresso. In Eclipse: tasto destro su Main.java ->
 * Run As -> Java Application (la working directory e' la root del progetto,
 * dove si trova config.properties).
 *
 * Argomento opzionale: percorso di un file di configurazione diverso.
 */
public class Main {

    public static void main(String[] args) throws Exception {
        Path configFile = Paths.get(args.length > 0 ? args[0] : "config.properties");
        BotConfig config = BotConfig.load(configFile);

        String token = config.getToken();
        String username = config.getUsername();
        if (token.isBlank() || token.startsWith("INSERISCI")) {
            System.err.println("ERRORE: imposta bot.token in " + configFile + " (o TELEGRAM_BOT_TOKEN).");
            System.exit(1);
        }
        if (username.isBlank() || username.startsWith("INSERISCI")) {
            System.err.println("ERRORE: imposta bot.username in " + configFile + " (o TELEGRAM_BOT_USERNAME).");
            System.exit(1);
        }

        // chat_member serve per rilevare i nuovi ingressi anche quando Telegram
        // non invia il messaggio di servizio (gruppi grandi, canali).
        // Per riceverlo il bot deve essere amministratore della chat.
        DefaultBotOptions options = new DefaultBotOptions();
        options.setAllowedUpdates(List.of("message", "chat_member"));

        SteadyWelcomeBot bot = new SteadyWelcomeBot(options, config);
        TelegramBotsApi api = new TelegramBotsApi(DefaultBotSession.class);
        api.registerBot(bot);

        System.out.println("Bot @" + username + " avviato. Premi Ctrl+C per fermarlo.");
    }
}
