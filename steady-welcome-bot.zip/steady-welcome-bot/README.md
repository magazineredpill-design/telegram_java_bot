# Steady Welcome Bot

Bot Telegram in Java che, quando un utente entra in un gruppo (o canale), mostra un link a un post di Steady.
Link, testo, pulsante, modalita' di invio e amministratori si configurano da Telegram, senza toccare il codice.

## Importare in Eclipse
1. Decomprimi lo zip.
2. `File > Import > Maven > Existing Maven Projects` e seleziona la cartella `steady-welcome-bot`
   (serve Eclipse con m2e, incluso nelle edizioni "Java Developers"; JDK 17 o superiore).
3. Attendi il download delle dipendenze (`pom.xml`).

## Configurare
1. Su Telegram apri **@BotFather** > `/newbot` e copia il token.
2. Modifica `config.properties`: `bot.token`, `bot.username`, `steady.link`.
   (Il token puo' anche stare nella variabile d'ambiente `TELEGRAM_BOT_TOKEN`.)
3. Avvia il bot (punto 5), scrivigli in privato `/myid`, copia il tuo ID in `admin.ids` e riavvia.

## Avviare
- Eclipse: tasto destro su `src/main/java/bot/steady/Main.java` > `Run As > Java Application`.
  La working directory e' la root del progetto, dove si trova `config.properties`.
- Da terminale: `mvn clean package` e poi `java -jar target/steady-welcome-bot.jar`
  (lancialo dalla cartella che contiene `config.properties`, oppure passa il percorso come argomento).

## Usare il bot
1. Aggiungi il bot al gruppo/canale **come amministratore**. Serve per ricevere gli ingressi
   (update `chat_member`), anche nei gruppi grandi e nei canali dove Telegram non invia il messaggio di servizio.
2. Quando entra un utente, il bot invia il messaggio con il link e un pulsante.
   Nei **canali** conviene `/setmode private`: il messaggio arriva in privato, ma solo a chi ha gia' avviato il bot.

## Comandi amministratore (solo in chat privata con il bot)
| Comando | Funzione |
|---|---|
| `/getconfig` | mostra la configurazione attuale |
| `/setlink <url>` | imposta il link Steady (https) |
| `/setmessage <testo>` | imposta il messaggio; segnaposto `{name}` e `{link}` |
| `/setbutton <testo>` | testo del pulsante |
| `/welcome on\|off` | attiva/disattiva il benvenuto |
| `/setmode chat\|private` | invio nella chat o in privato all'utente |
| `/addadmin <id>` / `/removeadmin <id>` | gestisce gli admin aggiunti da comando |
| `/test` | anteprima del benvenuto |
| `/myid` | mostra il tuo ID Telegram (per tutti) |

Le modifiche vengono salvate in `data/settings.properties` e restano dopo il riavvio.

## Struttura
```
steady-welcome-bot/
├── pom.xml
├── config.properties
├── .project / .classpath / .settings   (Eclipse)
└── src/main
    ├── java/bot/steady/
    │   ├── Main.java              avvio e registrazione del bot
    │   ├── SteadyWelcomeBot.java  logica: join e comandi admin
    │   └── BotConfig.java         lettura/scrittura configurazione
    └── resources/simplelogger.properties
```
